import requests
import json

city = input("Enter your city name: ")
response = requests.get('https://goweather.herokuapp.com/weather/' + city)
data = json.loads(response.text)
temperature = data.get('temperature')
wind = data.get('wind')
detail = data.get('description')
print('The temperature of', city, 'is', temperature)
print('Winds blowing at', wind)
print(detail, 'weather prevalent')
